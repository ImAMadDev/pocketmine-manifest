<?php
// PhpStorm metadata for Altay
namespace PHPSTORM_META {
    expectedReturnValues(
        \pocketmine\Server::getInstance(),
        \pocketmine\Server::class
    );
}
