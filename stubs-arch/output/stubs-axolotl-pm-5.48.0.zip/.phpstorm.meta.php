<?php
// PhpStorm metadata for Axolotl-PM
namespace PHPSTORM_META {
    expectedReturnValues(
        \pocketmine\Server::getInstance(),
        \pocketmine\Server::class
    );
}
