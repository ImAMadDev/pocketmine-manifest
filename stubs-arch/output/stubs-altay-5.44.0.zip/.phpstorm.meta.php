<?php
// PhpStorm metadata for PocketMine-MP
namespace PHPSTORM_META {
    expectedReturnValues(
        \pocketmine\Server::getInstance(),
        \pocketmine\Server::class
    );
}
